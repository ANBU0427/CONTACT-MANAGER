import express from "express";
import { register, login, getMe } from "../controllers/auth.controller.ts";
import { protect } from "../middleware/auth.middleware.ts";

const router = express.Router();

router.post("/register", register);
router.post("/login", login);
router.get("/me", protect, getMe);

export default router;
