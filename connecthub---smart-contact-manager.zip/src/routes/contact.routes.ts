import express from "express";
import {
  getContacts,
  getContact,
  createContact,
  updateContact,
  deleteContact,
  searchContacts,
} from "../controllers/contact.controller.ts";
import { protect } from "../middleware/auth.middleware.ts";

const router = express.Router();

// All contact routes are protected
router.use(protect);

router.route("/")
  .get(getContacts)
  .post(createContact);

router.get("/search", searchContacts);

router.route("/:id")
  .get(getContact)
  .put(updateContact)
  .delete(deleteContact);

export default router;
