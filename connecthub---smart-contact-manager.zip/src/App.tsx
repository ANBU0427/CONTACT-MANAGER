import React, { useState, useEffect, useMemo } from "react";
import { 
  Users, 
  Search, 
  Plus, 
  LogOut, 
  User as UserIcon, 
  Phone, 
  Mail, 
  Tag, 
  FileText, 
  Trash2, 
  Edit2, 
  X, 
  Save,
  Loader2,
  ChevronRight,
  ShieldCheck
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// --- Types ---

interface User {
  id: number;
  name: string;
  email: string;
}

interface Contact {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  notes: string | null;
  tags: string | null;
  created_at: string;
}

// --- Components ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem("token"));
  const [view, setView] = useState<"login" | "register" | "dashboard">("login");
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    notes: "",
    tags: ""
  });

  // Auth Forms
  const [authData, setAuthData] = useState({
    name: "",
    email: "",
    password: ""
  });

  useEffect(() => {
    if (token) {
      fetchMe();
      fetchContacts();
      setView("dashboard");
    }
  }, [token]);

  const fetchMe = async () => {
    try {
      const res = await fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.data);
      } else {
        handleLogout();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchContacts = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/contacts", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setContacts(data.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const endpoint = view === "login" ? "/api/auth/login" : "/api/auth/register";
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(authData)
      });
      const data = await res.json();
      if (data.success) {
        localStorage.setItem("token", data.token);
        setToken(data.token);
        setUser(data.user);
        setView("dashboard");
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
    setContacts([]);
    setView("login");
  };

  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const method = editingContact ? "PUT" : "POST";
    const endpoint = editingContact ? `/api/contacts/${editingContact.id}` : "/api/contacts";
    
    try {
      const res = await fetch(endpoint, {
        method,
        headers: { 
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      if (data.success) {
        fetchContacts();
        closeModal();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteContact = async (id: number) => {
    if (!confirm("Are you sure you want to delete this contact?")) return;
    try {
      const res = await fetch(`/api/contacts/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setContacts(contacts.filter(c => c.id !== id));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const openModal = (contact: Contact | null = null) => {
    if (contact) {
      setEditingContact(contact);
      setFormData({
        name: contact.name,
        email: contact.email || "",
        phone: contact.phone || "",
        notes: contact.notes || "",
        tags: contact.tags || ""
      });
    } else {
      setEditingContact(null);
      setFormData({ name: "", email: "", phone: "", notes: "", tags: "" });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingContact(null);
  };

  const filteredContacts = useMemo(() => {
    if (!searchQuery) return contacts;
    const q = searchQuery.toLowerCase();
    return contacts.filter(c => 
      c.name.toLowerCase().includes(q) || 
      (c.email?.toLowerCase().includes(q)) ||
      (c.tags?.toLowerCase().includes(q))
    );
  }, [contacts, searchQuery]);

  if (!token && (view === "login" || view === "register")) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center p-4 font-serif">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-[32px] shadow-xl w-full max-w-md border border-[#5A5A40]/10"
        >
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-[#5A5A40] rounded-full flex items-center justify-center mb-4 shadow-lg">
              <Users className="text-white w-8 h-8" />
            </div>
            <h1 className="text-3xl font-bold text-[#1A1A1A] tracking-tight">ConnectHub</h1>
            <p className="text-[#5A5A40] opacity-70 italic">Smart Contact Manager</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-4">
            {view === "register" && (
              <div>
                <label className="block text-sm font-medium text-[#1A1A1A] mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all"
                  placeholder="John Doe"
                  value={authData.name}
                  onChange={(e) => setAuthData({ ...authData, name: e.target.value })}
                />
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-[#1A1A1A] mb-1">Email Address</label>
              <input
                type="email"
                required
                className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all"
                placeholder="john@example.com"
                value={authData.email}
                onChange={(e) => setAuthData({ ...authData, email: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1A1A1A] mb-1">Password</label>
              <input
                type="password"
                required
                className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all"
                placeholder="••••••••"
                value={authData.password}
                onChange={(e) => setAuthData({ ...authData, password: e.target.value })}
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#5A5A40] text-white py-3 rounded-2xl font-semibold shadow-lg hover:bg-[#4A4A30] transition-all flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin w-5 h-5" /> : (view === "login" ? "Sign In" : "Create Account")}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button 
              onClick={() => setView(view === "login" ? "register" : "login")}
              className="text-[#5A5A40] hover:underline text-sm font-medium"
            >
              {view === "login" ? "Don't have an account? Register" : "Already have an account? Login"}
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] font-sans text-[#1A1A1A]">
      {/* Header */}
      <header className="bg-white border-b border-[#5A5A40]/10 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#5A5A40] rounded-xl flex items-center justify-center shadow-md">
              <Users className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">ConnectHub</h1>
              <div className="flex items-center gap-1 text-[10px] uppercase tracking-widest text-[#5A5A40] font-bold opacity-60">
                <ShieldCheck className="w-3 h-3" />
                Secure Manager
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-[#F5F5F0] rounded-full border border-[#5A5A40]/5">
              <UserIcon className="w-4 h-4 text-[#5A5A40]" />
              <span className="text-sm font-medium">{user?.name}</span>
            </div>
            <button 
              onClick={handleLogout}
              className="p-2 text-[#5A5A40] hover:bg-[#F5F5F0] rounded-full transition-colors"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Actions Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#5A5A40] w-5 h-5 opacity-50" />
            <input 
              type="text" 
              placeholder="Search by name, email, or tags..."
              className="w-full pl-12 pr-4 py-3 bg-white rounded-2xl border border-[#5A5A40]/10 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/30 shadow-sm transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <button 
            onClick={() => openModal()}
            className="w-full md:w-auto bg-[#5A5A40] text-white px-6 py-3 rounded-2xl font-semibold shadow-lg hover:bg-[#4A4A30] transition-all flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add New Contact
          </button>
        </div>

        {/* Contacts Grid */}
        {loading && contacts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-12 h-12 text-[#5A5A40] animate-spin mb-4" />
            <p className="text-[#5A5A40] font-medium italic">Loading your connections...</p>
          </div>
        ) : filteredContacts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredContacts.map((contact) => (
                <motion.div 
                  layout
                  key={contact.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-white p-6 rounded-[24px] shadow-sm border border-[#5A5A40]/5 hover:shadow-md transition-all group relative overflow-hidden"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-[#F5F5F0] rounded-2xl flex items-center justify-center text-[#5A5A40] font-bold text-xl">
                        {contact.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg leading-tight">{contact.name}</h3>
                        <div className="flex items-center gap-1 text-xs text-[#5A5A40] opacity-60">
                          <Tag className="w-3 h-3" />
                          {contact.tags || "No tags"}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => openModal(contact)}
                        className="p-2 text-[#5A5A40] hover:bg-[#F5F5F0] rounded-full transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDeleteContact(contact.id)}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {contact.email && (
                      <div className="flex items-center gap-3 text-sm text-[#5A5A40]">
                        <Mail className="w-4 h-4 opacity-70" />
                        {contact.email}
                      </div>
                    )}
                    {contact.phone && (
                      <div className="flex items-center gap-3 text-sm text-[#5A5A40]">
                        <Phone className="w-4 h-4 opacity-70" />
                        {contact.phone}
                      </div>
                    )}
                    {contact.notes && (
                      <div className="flex items-start gap-3 text-sm text-[#5A5A40] bg-[#F5F5F0]/50 p-3 rounded-xl border border-[#5A5A40]/5">
                        <FileText className="w-4 h-4 mt-0.5 opacity-70 shrink-0" />
                        <p className="line-clamp-2 italic">{contact.notes}</p>
                      </div>
                    )}
                  </div>

                  <div className="mt-6 pt-4 border-t border-[#5A5A40]/5 flex items-center justify-between">
                    <span className="text-[10px] text-[#5A5A40] opacity-40 uppercase font-bold tracking-widest">
                      Added {new Date(contact.created_at).toLocaleDateString()}
                    </span>
                    <ChevronRight className="w-4 h-4 text-[#5A5A40] opacity-20" />
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="bg-white rounded-[32px] p-12 text-center border border-dashed border-[#5A5A40]/20">
            <div className="w-20 h-20 bg-[#F5F5F0] rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="text-[#5A5A40] w-10 h-10 opacity-20" />
            </div>
            <h2 className="text-2xl font-bold mb-2">No contacts found</h2>
            <p className="text-[#5A5A40] opacity-60 max-w-sm mx-auto mb-8">
              {searchQuery ? `No results for "${searchQuery}". Try a different search term.` : "Start building your network by adding your first contact."}
            </p>
            {!searchQuery && (
              <button 
                onClick={() => openModal()}
                className="bg-[#5A5A40] text-white px-8 py-3 rounded-2xl font-semibold shadow-lg hover:bg-[#4A4A30] transition-all"
              >
                Add Your First Contact
              </button>
            )}
          </div>
        )}
      </main>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeModal}
              className="absolute inset-0 bg-[#1A1A1A]/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-lg rounded-[32px] shadow-2xl relative z-10 overflow-hidden border border-[#5A5A40]/10"
            >
              <div className="p-6 border-b border-[#5A5A40]/10 flex items-center justify-between bg-[#F5F5F0]/30">
                <h2 className="text-xl font-bold">{editingContact ? "Edit Contact" : "New Contact"}</h2>
                <button onClick={closeModal} className="p-2 hover:bg-[#F5F5F0] rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveContact} className="p-8 space-y-6">
                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-[#5A5A40] uppercase tracking-widest mb-2">Full Name *</label>
                    <input 
                      type="text" 
                      required
                      className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all"
                      placeholder="Jane Cooper"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-[#5A5A40] uppercase tracking-widest mb-2">Email</label>
                      <input 
                        type="email" 
                        className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all"
                        placeholder="jane@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-[#5A5A40] uppercase tracking-widest mb-2">Phone</label>
                      <input 
                        type="tel" 
                        className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all"
                        placeholder="+1 (555) 000-0000"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-[#5A5A40] uppercase tracking-widest mb-2">Tags (Comma separated)</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all"
                      placeholder="Friends, Work, Family"
                      value={formData.tags}
                      onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-[#5A5A40] uppercase tracking-widest mb-2">Notes</label>
                    <textarea 
                      rows={3}
                      className="w-full px-4 py-3 rounded-2xl border border-[#5A5A40]/20 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/50 transition-all resize-none"
                      placeholder="Add some details about this contact..."
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <button 
                    type="button"
                    onClick={closeModal}
                    className="flex-1 px-6 py-4 rounded-2xl font-bold text-[#5A5A40] bg-[#F5F5F0] hover:bg-[#E5E5E0] transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    disabled={loading}
                    className="flex-[2] bg-[#5A5A40] text-white px-6 py-4 rounded-2xl font-bold shadow-lg hover:bg-[#4A4A30] transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="animate-spin w-5 h-5" /> : (
                      <>
                        <Save className="w-5 h-5" />
                        {editingContact ? "Update Contact" : "Create Contact"}
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-t border-[#5A5A40]/10 mt-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-[#5A5A40] opacity-40">
            <Users className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-widest">ConnectHub © 2026</span>
          </div>
          <div className="flex items-center gap-8 text-sm font-medium text-[#5A5A40] opacity-60">
            <a href="#" className="hover:opacity-100 transition-opacity">Privacy Policy</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Terms of Service</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Help Center</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
