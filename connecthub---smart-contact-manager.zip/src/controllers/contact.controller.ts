import { Response, NextFunction } from "express";
import db from "../config/db.ts";
import { AuthRequest } from "../middleware/auth.middleware.ts";

export const getContacts = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const contacts = db.prepare("SELECT * FROM contacts WHERE user_id = ? ORDER BY created_at DESC").all(req.user?.id);
    res.status(200).json({ success: true, count: contacts.length, data: contacts });
  } catch (err) {
    next(err);
  }
};

export const getContact = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const contact = db.prepare("SELECT * FROM contacts WHERE id = ? AND user_id = ?").get(req.params.id, req.user?.id);
    if (!contact) {
      return res.status(404).json({ success: false, message: "Contact not found" });
    }
    res.status(200).json({ success: true, data: contact });
  } catch (err) {
    next(err);
  }
};

export const createContact = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { name, email, phone, notes, tags } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: "Name is required" });
    }

    const result = db.prepare(
      "INSERT INTO contacts (user_id, name, email, phone, notes, tags) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(req.user?.id, name, email || null, phone || null, notes || null, tags || null);

    const contact = db.prepare("SELECT * FROM contacts WHERE id = ?").get(result.lastInsertRowid);

    res.status(201).json({ success: true, data: contact });
  } catch (err) {
    next(err);
  }
};

export const updateContact = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { name, email, phone, notes, tags } = req.body;

    const existingContact = db.prepare("SELECT * FROM contacts WHERE id = ? AND user_id = ?").get(req.params.id, req.user?.id);
    if (!existingContact) {
      return res.status(404).json({ success: false, message: "Contact not found" });
    }

    db.prepare(`
      UPDATE contacts 
      SET name = ?, email = ?, phone = ?, notes = ?, tags = ? 
      WHERE id = ? AND user_id = ?
    `).run(
      name || (existingContact as any).name,
      email !== undefined ? email : (existingContact as any).email,
      phone !== undefined ? phone : (existingContact as any).phone,
      notes !== undefined ? notes : (existingContact as any).notes,
      tags !== undefined ? tags : (existingContact as any).tags,
      req.params.id,
      req.user?.id
    );

    const updatedContact = db.prepare("SELECT * FROM contacts WHERE id = ?").get(req.params.id);

    res.status(200).json({ success: true, data: updatedContact });
  } catch (err) {
    next(err);
  }
};

export const deleteContact = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const result = db.prepare("DELETE FROM contacts WHERE id = ? AND user_id = ?").run(req.params.id, req.user?.id);

    if (result.changes === 0) {
      return res.status(404).json({ success: false, message: "Contact not found" });
    }

    res.status(200).json({ success: true, data: {} });
  } catch (err) {
    next(err);
  }
};

export const searchContacts = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({ success: false, message: "Search query is required" });
    }

    const searchTerm = `%${q}%`;
    const contacts = db.prepare(`
      SELECT * FROM contacts 
      WHERE user_id = ? AND (name LIKE ? OR email LIKE ? OR tags LIKE ?)
      ORDER BY name ASC
    `).all(req.user?.id, searchTerm, searchTerm, searchTerm);

    res.status(200).json({ success: true, count: contacts.length, data: contacts });
  } catch (err) {
    next(err);
  }
};
